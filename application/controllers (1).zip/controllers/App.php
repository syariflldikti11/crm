<?php

class App extends CI_Controller {
 
	function __construct(){
    parent::__construct();
    $this->load->database();
    $this->load->model('m_sakip');
    if($this->session->userdata('akses') <> 1){
        redirect(base_url('login_sakip'));
        }
  }
  function upload_bukti_dukung(){
    $id_iku=$this->input->post('id_iku');
    $menu=$this->input->post('menu');
    $id_triwulan=$this->input->post('id_triwulan');
 $file = $this->uploadFile();
                         
    $datakib = array(
    
        'id_iku' => $id_iku,
        'id_triwulan' => $id_triwulan,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_bukti_dukung');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/$menu/".$id_iku);
    }
  public function uploadFile()
	{
    $config['upload_path']          = 'upload';
    $config['allowed_types']        = 'pdf|jpg|jpeg|png|pdf|xls|xlsx|doc|docx';
    $config['overwrite']			= false;
     $config['max_size']             = 5000; // 1MB
$config['encrypt_name'] = TRUE;

    $this->load->library('upload', $config);
	$this->upload->initialize($config);

	    if ($this->upload->do_upload('file')) 
	    {
	        return $this->upload->data("file_name");
	    }
	     $error = $this->upload->display_errors();
	     echo $error;
	     exit;
	    // return "default.jpg";
	}
	  public function uploadppks()
	{
    $config['upload_path']          = 'upload';
    $config['allowed_types']        = 'pdf|jpg|jpeg|png|pdf|xls|xlsx|doc|docx';
    $config['overwrite']			= false;
     $config['max_size']             = 5000; // 1MB
$config['encrypt_name'] = TRUE;

    $this->load->library('upload', $config);
	$this->upload->initialize($config);

	    if ($this->upload->do_upload('ppks')) 
	    {
	        return $this->upload->data("file_name");
	    }
	     $error = $this->upload->display_errors();
	     echo $error;
	     exit;
	    // return "default.jpg";
	}
	  public function uploadnarkoba()
	{
    $config['upload_path']          = 'upload';
    $config['allowed_types']        = 'pdf|jpg|jpeg|png|pdf|xls|xlsx|doc|docx';
    $config['overwrite']			= false;
     $config['max_size']             = 5000; // 1MB
$config['encrypt_name'] = TRUE;

    $this->load->library('upload', $config);
	$this->upload->initialize($config);

	    if ($this->upload->do_upload('narkoba')) 
	    {
	        return $this->upload->data("file_name");
	    }
	     $error = $this->upload->display_errors();
	     echo $error;
	     exit;
	    // return "default.jpg";
	}
	  public function uploadkorupsi()
	{
    $config['upload_path']          = 'upload';
    $config['allowed_types']        = 'pdf|jpg|jpeg|png|pdf|xls|xlsx|doc|docx';
    $config['overwrite']			= false;
     $config['max_size']             = 5000; // 1MB
$config['encrypt_name'] = TRUE;

    $this->load->library('upload', $config);
	$this->upload->initialize($config);

	    if ($this->upload->do_upload('korupsi')) 
	    {
	        return $this->upload->data("file_name");
	    }
	     $error = $this->upload->display_errors();
	     echo $error;
	     exit;
	    // return "default.jpg";
	}
   function index()
  {

    $tahun=$this->session->userdata('tahun');
    $data = array(
        'judul' => 'Dashboard',
        'tahun'=> $tahun,
        'dt_ikk'=> $this->m_sakip->get_ikk_home(),
        'dt_pk'=> $this->m_sakip->get_pk(),
        
    );	
    $this->template->load('sakip/admin/template', 'sakip/admin/home', $data);
    
}


function triwulan()
{

  $tahun=$this->session->userdata('tahun');
  $data = array(
    'tahun'=> $tahun,
      'judul' => 'Setting Triwulan',
      'dt_triwulan'=> $this->m_sakip->get_data('sakip_triwulan'),   
  );	
  $this->template->load('sakip/admin/template', 'sakip/admin/sakip_triwulan', $data);
  
}
function update_triwulan()
	{
       
		$this->form_validation->set_rules('id_triwulan','id_triwulan','required');
		if($this->form_validation->run() === FALSE)
        redirect('app/triwulan');
		else
		{
			$this->m_umum->update_data("sakip_triwulan");
			 $notif = " Input triwulan Berhasil";
            $this->session->set_flashdata('update', $notif);
            redirect('app/triwulan');
		}
   
	}
function user()
{
  if($this->session->userdata('akses')=='1' ) 
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Standar Layanan',
      'dt_user'=> $this->m_sakip->get_data('sakip_user'),
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/user', $data);
     
}
function renaksi()
{
  
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Rencana Aksi Triwulan',
  
      'dt_renaksi'=> $this->m_sakip->get_renaksi(),
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/renaksi', $data);
     
}
function update_renaksi()
	{
       
		$this->form_validation->set_rules('id_ikk','id_ikk','required');
        $id=$this->input->post('id_sasaran_kegiatan');
		if($this->form_validation->run() === FALSE)
        redirect('app/target_kinerja');
		else
		{
			$this->m_umum->update_data("sakip_ikk");
			 $notif = " Input Renaksi Berhasil";
            $this->session->set_flashdata('update', $notif);
            redirect('app/renaksi');
		}
   
	}
function simpan_renaksi() { 
  
  $this->db->set('id_renaksi', 'UUID()', FALSE);
  $this->form_validation->set_rules('id_ikk','id_ikk','required');
  if($this->form_validation->run() === FALSE)
  redirect('app/renaksi');
  else
  {
      
      $this->m_umum->set_data("sakip_renaksi");
      $notif = "Tambah Data Berhasil";
      $this->session->set_flashdata('success', $notif);
     redirect('app/renaksi');
  }
 
}


function analisa()
{

 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Analisa Capaian Kinerja',
      'dt_iku'=> $this->m_sakip->get_iku(),
   
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/analisa', $data);
     
}
function analisa_capaian_kinerja($ida)
{
 
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Analisa Capaian Kinerja',
      'id_iku' => $ida,
      'dt_analisa'=> $this->m_sakip->get_analisa($ida),
      'dt_tw'=> $this->m_sakip->get_triwulan(),
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/analisa_capaian_kinerja', $data);
 
}
function cetak_analisa()
	{
	
		$data['dt_analisa']=$this->m_sakip->get_cetak_analisa();
		$this->load->view('sakip/admin/cetak_analisa',$data);
		
	}
function simpan_analisa_capaian_kinerja() { 

  $this->db->set('id_analisa', 'UUID()', FALSE);
  $id=$this->input->post('id_iku');
  $this->form_validation->set_rules('progress', 'progress', 'trim|required|min_length[1000]');
  $this->form_validation->set_rules('kendala', 'kendala', 'required');
  $this->form_validation->set_rules('tindak_lanjut', 'required');

  if($this->form_validation->run() === FALSE) {
  $notif = "Jangan menggunakan inspect element";
  $this->session->set_flashdata('delete', $notif);

  redirect(base_url()."app/analisa_capaian_kinerja/".$id);
  }
  else
  {
      
      $this->m_umum->set_data("sakip_analisa");
      $notif = "Tambah Data Berhasil";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/analisa_capaian_kinerja/".$id);
  }
 
}
function update_analisa_capaian_kinerja()
	{
      
		$this->form_validation->set_rules('id_analisa','id_analisa','required');
    $this->form_validation->set_rules('progress', 'progress', 'trim|required|min_length[1000]');
  $this->form_validation->set_rules('kendala', 'kendala', 'trim|required');
  $this->form_validation->set_rules('tindak_lanjut', 'tindak_lanjut', 'trim|required');
    $id=$this->input->post('id_iku');
		if($this->form_validation->run() === FALSE) {
      $notif = "Jangan menggunakan inspect element";
      $this->session->set_flashdata('delete', $notif);
    
      redirect(base_url()."app/analisa_capaian_kinerja/".$id);
      }
		else
		{
			$this->m_umum->update_data("sakip_analisa");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/analisa_capaian_kinerja/".$id);
		}
    
	}
  function validasi_analisa_capaian_kinerja()
  {
       
    $this->form_validation->set_rules('id_analisa','id_analisa','required');
    $this->form_validation->set_rules('status_analisa', 'status_analisa');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/analisa_capaian_kinerja/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_analisa");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/analisa_capaian_kinerja/".$id);
    }
   
  }
function delete_analisa_capaian_kinerja($id,$id_iku)
{
  
  $this->m_umum->hapus('sakip_analisa','id_analisa',$id);
   $notif = " Data berhasil dihapuskan";
          $this->session->set_flashdata('delete', $notif);
          redirect(base_url()."app/analisa_capaian_kinerja/".$id_iku);
  
}

function capaian_kinerja()
{
 
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Capaian Kinerja',
      'dt_iku'=> $this->m_sakip->get_iku(),
   
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/capaian_kinerja', $data);
     
}
function iku1($id_iku)
{

 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),

    'dt_iku1'=> $this->m_sakip->get_iku1($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku1', $data);
    
}

function simpan_iku1(){
   
  $this->db->set('id_iku1', 'UUID()', FALSE);
    $this->form_validation->set_rules('nilai_survey','nilai_survey','required');
    $id_iku=$this->input->post('id_iku');
    $nilai_survey=$this->input->post('nilai_survey');
    $id_triwulan=$this->input->post('id_triwulan');
 $file = $this->uploadFile();
       if($this->form_validation->run() === FALSE) {
  redirect(base_url()."app/iku1/".$id_iku);
  }    else{


    $datakib = array(
    
        'nilai_survey' => $nilai_survey,
        'id_triwulan' => $id_triwulan,
        'id_iku' => $id_iku,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_iku1');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/iku1/".$id_iku);
              }
           
    }
    function update_iku1(){
        $id_iku1 = $this->input->post('id_iku1');
        $id_iku = $this->input->post('id_iku');
        $nilai_survey = $this->input->post('nilai_survey');
        $old = $this->input->post('old_file');
            
            if (!empty($_FILES["file"]["name"])) {
                  $file = $this->uploadFile();
                  unlink("./upload/$old");
                } else {
                    $file = $old;
                }
            $data_update = array(
                'nilai_survey' => $nilai_survey,
                'file' => $file
                );
                $where = array('id_iku1' => $id_iku1);
                $res = $this->m_umum->UpdateData('sakip_iku1', $data_update, $where);
                if($res>=1){
                   
                    $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
              redirect(base_url()."app/iku1/".$id_iku);
                }else{
                    echo "<h1>GAGAL</h1>";
                }
            }

  function cetak_iku1($id_iku)
  {
   
    $data['dt_iku1']=$this->m_sakip->get_iku1($id_iku);
    $this->load->view('sakip/laporan/cetak_iku1',$data);
    
  }
  function delete_iku1($id,$id_iku)
{

    $this->m_umum->hapus('sakip_iku1','id_iku1',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku1/".$id_iku);

}
function iku2($id_iku)
{
 
 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_pts'=> $this->m_sakip->get_pts_iku2(),
    'dt_iku2'=> $this->m_sakip->get_iku2($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku2', $data);
     
}

function simpan_iku2(){
  
 
    $this->form_validation->set_rules('kode_pt','kode_pt','required');
    $id_iku=$this->input->post('id_iku');
    $kode_pt=$this->input->post('kode_pt');
    $id_triwulan=$this->input->post('id_triwulan');
    $nama_pt=$this->input->post('nama_pt');
    $provinsi=$this->input->post('provinsi');
    $nm_akred=$this->input->post('nm_akred');
    $sk_akred_sp=$this->input->post('sk_akred_sp');
    $tst_sk_akred_sp=$this->input->post('tst_sk_akred_sp');
 $file = $this->uploadFile();
       if($this->form_validation->run() === FALSE) {
  redirect(base_url()."app/iku2/".$id_iku);
  }    else{


    $datakib = array(
    
        'kode_pt' => $kode_pt,
        'id_triwulan' => $id_triwulan,
        'id_iku' => $id_iku,
        'nama_pt' => $nama_pt,
        'provinsi' => $provinsi,
        'nm_akred' => $nm_akred,
        'sk_akred_sp' => $sk_akred_sp,
        'tst_sk_akred_sp' => $tst_sk_akred_sp,
        'id_iku' => $id_iku,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_iku2');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/iku2/".$id_iku);
              }
           
    }
     
function import_iku2() { 
  $id_triwulan=$this->input->post('id_triwulan');
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $id_iku=$this->input->post('id_iku');

  $query1 = $this->db->query("SELECT 
* from sakip_akred_pt where  nm_akred is not NULL  and
kode_pt NOT IN(
SELECT kode_pt FROM sakip_iku2) ");
   
  foreach ($query1->result() as $a) {
    
    $sql1 = "insert into sakip_iku2 (id_iku2,kode_pt,nama_pt,provinsi,nm_akred,sk_akred_sp,tst_sk_akred_sp,status_iku,catatan,id_iku,id_triwulan) values (NULL,'$a->kode_pt','$a->nama_pt','$a->provinsi_pt','$a->nm_akred','$a->sk_akred_sp','$a->tst_sk_akred_sp','0','','$id_iku','$id_triwulan')";
    $this->db->query($sql1);
                }
                
                $notif = "Tambah Data Berhasil";
                $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/iku2/".$id_iku);
  
  }
   function update_iku2(){
        $id_iku2 = $this->input->post('id_iku2');
        $id_iku = $this->input->post('id_iku');
        $nm_akred = $this->input->post('nm_akred');
        $sk_akred_sp = $this->input->post('sk_akred_sp');
        $tst_sk_akred_sp = $this->input->post('tst_sk_akred_sp');
        $old = $this->input->post('old_file');
            
            if (!empty($_FILES["file"]["name"])) {
                  $file = $this->uploadFile();
                  unlink("./upload/$old");
                } else {
                    $file = $old;
                }
            $data_update = array(
                'nm_akred' => $nm_akred,
                'sk_akred_sp' => $sk_akred_sp,
                'tst_sk_akred_sp' => $tst_sk_akred_sp,
                'file' => $file
                );
                $where = array('id_iku2' => $id_iku2);
                $res = $this->m_umum->UpdateData('sakip_iku2', $data_update, $where);
                if($res>=1){
                   
                    $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
              redirect(base_url()."app/iku2/".$id_iku);
                }else{
                    echo "<h1>GAGAL</h1>";
                }
            }

function delete_iku2($id,$id_iku)
{
  
    $this->m_umum->hapus('sakip_iku2','id_iku2',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku2/".$id_iku);
 
}
function cetak_iku2($id_iku)
	{
	
    $data['dt_iku2']=$this->m_sakip->get_iku2($id_iku);
		$this->load->view('sakip/laporan/cetak_iku2',$data);
		
	}
function iku3($id_iku)
{
 
 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_iku3'=> $this->m_sakip->get_iku3($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku3', $data);
     
}
function simpan_iku3() { 
  $id_triwulan=$this->input->post('id_triwulan');
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $id_iku=$this->input->post('id_iku');

  $query1 = $this->db->query("SELECT 
npsn,
nm_lemb,
nm_jenj_didik,
nm_pd,
nipd,
sks_smt,
id_smt
FROM
sakip_mhs_mbkm
where id_jenj_didik between 22 and 30 and sks_smt >=10
and nipd NOT IN(
SELECT nipd  FROM sakip_iku3)
and id_smt NOT IN(
SELECT id_smt  FROM sakip_iku3)
");
   $query2 = $this->db->query("SELECT 
npsn,
nm_lemb,
nm_jenj_didik,
nm_pd,
nipd,
sks_smt,
id_smt
FROM
sakip_mhs_mbkm
where id_jenj_didik < 22 and sks_smt >=5
and nipd NOT IN(
SELECT nipd  FROM sakip_iku3)
and id_smt NOT IN(
SELECT id_smt  FROM sakip_iku3)

");
  foreach ($query1->result() as $a) {
 $sql1 = "insert into sakip_iku3 (id_iku3,kode_pt,nama_pt,nm_jenj_didik,nm_pd,nipd,sks_smt,id_smt,id_iku,id_triwulan,status_iku,catatan) values (NULL,'$a->npsn','$a->nm_lemb','$a->nm_jenj_didik','".addslashes($a->nm_pd)."','$a->nipd','$a->sks_smt','$a->id_smt','$id_iku','$id_triwulan','0','')";
    $this->db->query($sql1);
                }
                foreach ($query2->result() as $b) {
                 
    $sql2 = "insert into sakip_iku3 (id_iku3,kode_pt,nama_pt,nm_jenj_didik,nm_pd,nipd,sks_smt,id_smt,id_iku,id_triwulan,status_iku,catatan) values (NULL,'$b->npsn','$b->nm_lemb','$b->nm_jenj_didik','".addslashes($b->nm_pd)."','$b->nipd','$b->sks_smt','$b->id_smt','$id_iku','$id_triwulan','0','')";
    $this->db->query($sql2);
                }
                 $this->db->query("UPDATE sakip_iku3 
SET  bobot =  CASE  
                        WHEN sks_smt >=20 THEN 1 
                        WHEN sks_smt <20 THEN 0.50 
                        end
                       ");
                $notif = "Tambah Data Berhasil";
                $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/iku3/".$id_iku);
  
  }
  function delete_iku3(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("delete From sakip_iku3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data berhasil dihapuskan";
      $this->session->set_flashdata('delete', $notif);
      redirect(base_url()."app/iku3/".$id_iku);
  }
  function cetak_iku3($id_iku)
	{
	
    $data['dt_iku3']=$this->m_sakip->get_iku3($id_iku);
		$this->load->view('sakip/laporan/cetak_iku3',$data);
		
	}

function iku4($id_iku)
{

 $tahun=$this->session->userdata('tahun');
  
  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_pts'=> $this->m_sakip->get_pts(),
    'dt_iku4'=> $this->m_sakip->get_iku4($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),

    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );
  
  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku4', $data);
     
}


function simpan_iku4(){

  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_iku4',$kode_unik);
  $this->form_validation->set_rules(
    'kode_pt', 'Kode PT',
    'required|is_unique[sakip_iku4.kode_pt]');
    $kode_pt=$this->input->post('kode_pt');
    $id_iku=$this->input->post('id_iku');
    $nama_pt=$this->input->post('nama_pt');
    $id_triwulan=$this->input->post('id_triwulan');
 $file = $this->uploadFile();
       if($this->form_validation->run() === FALSE) {
  $notif = "PTS Sudah Ada/Sudah Menjadi Capaian ditahun Sebelumnya";
  $this->session->set_flashdata('delete', $notif);
  redirect(base_url()."app/iku4/".$id_iku);
  }    else{


    $datakib = array(
    
        'kode_pt' => $kode_pt,
        'nama_pt' => $nama_pt,
        'id_triwulan' => $id_triwulan,
        'id_iku' => $id_iku,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_iku4');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/iku4/".$id_iku);
              }
           
    }

     function update_iku4()
     {
     $id=$this->input->post('id_iku');
     $id_iku4=$this->input->post('id_iku4');

                         if (!empty($_FILES['file']['name'])) {
     $file = $this->uploadFile();
      } else {
          $file= $this->input->post("old_file");
      }
    $data_update = array(
    
        'id_iku4' => $id_iku4,
        'file' => $file
        );
   $where = array('id_iku4' => $id_iku4);
        $res = $this->m_umum->UpdateData('sakip_iku4', $data_update, $where);
     $notif = " Update data berhasil";
              $this->session->set_flashdata('success', $notif);
               redirect(base_url()."app/iku4/".$id);
    }
function delete_iku4($id,$id_iku)
{
 
    $this->m_umum->hapus('sakip_iku4','id_iku4',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku4/".$id_iku);
 
}
function simpan_detail_iku4() { 
 
    $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_detail_iku4',$kode_unik);
   $this->form_validation->set_rules(
    'detail_kode_pt', 'detail_kode_pt',
    'required|is_unique[detail_sakip_iku4.detail_kode_pt]');
  $id_iku4=$this->input->post('id_iku4');

  if($this->form_validation->run() === FALSE)
  {
  $notif = "PTS Sudah Ada/Sudah Menjadi Capaian ditahun Sebelumnya";
  $this->session->set_flashdata('delete', $notif); 
  redirect(base_url()."app/detail_iku4/".$id_iku4);
}
  else
  {
      
      $this->m_umum->set_data("detail_sakip_iku4");
      $notif = "Tambah Data Berhasil";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/detail_iku4/".$id_iku4);
  }

}

function delete_detail_iku4($id,$id_iku4)
{

    $this->m_umum->hapus('detail_sakip_iku4','id_detail_iku4',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/detail_iku4/".$id_iku4);
 
}
function detail_iku4($id_iku4)
{

 $tahun=$this->session->userdata('tahun');
  
  $data = array(
    'id'=>$id_iku4,
    'd'=> $this->m_sakip->m_iku4($id_iku4),
    'dt_pts'=> $this->m_sakip->get_pts_all(),
    'dt_detail_iku4'=> $this->m_sakip->get_detail_iku4($id_iku4),

    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );
  
  
  $this->template->load('sakip/admin/template', 'sakip/admin/detail_iku4', $data);
     
}
function cetak_iku4($id_iku)
{
 
  $data['dt_iku4']=$this->m_sakip->get_iku4($id_iku);
  $this->load->view('sakip/laporan/cetak_iku4',$data);
  
}
function iku5($id_iku)
{

 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_iku5'=> $this->m_sakip->get_iku5($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku5', $data);
    
}
function simpan_iku5() { 
  $id_triwulan=$this->input->post('id_triwulan');
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $id_iku=$this->input->post('id_iku');

   $query1 = $this->db->query("SELECT 
npsn,
nm_lemb,
nm_jenj_didik,
nm_pd,
nipd,
sks_smt,
id_smt
FROM
sakip_mhs_mbkm
where id_jenj_didik between 22 and 30 and sks_smt >=10
and nipd NOT IN(
SELECT nipd  FROM sakip_iku5)
and id_smt NOT IN(
SELECT id_smt  FROM sakip_iku5)
");
   $query2 = $this->db->query("SELECT 
npsn,
nm_lemb,
nm_jenj_didik,
nm_pd,
nipd,
sks_smt,
id_smt
FROM
sakip_mhs_mbkm
where id_jenj_didik < 22 and sks_smt >=5
and nipd NOT IN(
SELECT nipd  FROM sakip_iku5)
and id_smt NOT IN(
SELECT id_smt  FROM sakip_iku5)

");
  foreach ($query1->result() as $a) {
 $sql1 = "insert into sakip_iku5 (id_iku5,kode_pt,nama_pt,nm_jenj_didik,nm_pd,nipd,sks_smt,id_smt,id_iku,id_triwulan,status_iku,catatan) values (NULL,'$a->npsn','$a->nm_lemb','$a->nm_jenj_didik','".addslashes($a->nm_pd)."','$a->nipd','$a->sks_smt','$a->id_smt','$id_iku','$id_triwulan','0','')";
    $this->db->query($sql1);
                }
                foreach ($query2->result() as $b) {
                 
    $sql2 = "insert into sakip_iku5 (id_iku5,kode_pt,nama_pt,nm_jenj_didik,nm_pd,nipd,sks_smt,id_smt,id_iku,id_triwulan,status_iku,catatan) values (NULL,'$b->npsn','$b->nm_lemb','$b->nm_jenj_didik','".addslashes($b->nm_pd)."','$b->nipd','$b->sks_smt','$b->id_smt','$id_iku','$id_triwulan','0','')";
    $this->db->query($sql2);
                }
                 $this->db->query("UPDATE sakip_iku5
SET  bobot =  CASE  
                        WHEN sks_smt >=20 THEN 1 
                        WHEN sks_smt <20 THEN 0.50 
                        end
                       ");
                $notif = "Tambah Data Berhasil";
                $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/iku5/".$id_iku);
  
  }
  function delete_iku5(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("delete From sakip_iku5 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data berhasil dihapuskan";
      $this->session->set_flashdata('delete', $notif);
      redirect(base_url()."app/iku5/".$id_iku);
  }
  function cetak_iku5($id_iku)
  {
  
    $data['dt_iku5']=$this->m_sakip->get_iku5($id_iku);
    $this->load->view('sakip/laporan/cetak_iku5',$data);
    
  }
function iku6($id_iku)
{

 $tahun=$this->session->userdata('tahun');
  
  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_pts'=> $this->m_sakip->get_pts(),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_iku6'=> $this->m_sakip->get_iku6($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),

    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );
  
  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku6', $data);
     
}

function simpan_iku6(){
   
 $this->db->set('id_iku6', 'UUID()', FALSE);
    $this->form_validation->set_rules(
    'kode_pt', 'Kode PT',
    'required|is_unique[sakip_iku6.kode_pt]');
    $kode_pt=$this->input->post('kode_pt');
    $id_iku=$this->input->post('id_iku');
    $nama_pt=$this->input->post('nama_pt');
    $bentuk_ppks=$this->input->post('bentuk_ppks');
    $bentuk_narkoba=$this->input->post('bentuk_narkoba');
    $bentuk_korupsi=$this->input->post('bentuk_korupsi');
    $id_triwulan=$this->input->post('id_triwulan');
  $ppks = $this->uploadppks();
   $narkoba = $this->uploadnarkoba();
    $korupsi = $this->uploadkorupsi();
                         if($this->form_validation->run() === FALSE) {
  $notif = "PTS Sudah Ada/Sudah Menjadi Capaian ditahun Sebelumnya";
  $this->session->set_flashdata('delete', $notif);
  redirect(base_url()."app/iku6/".$id_iku);
  }  else {
    $datakib = array(
    
        'kode_pt' => $kode_pt,
        'nama_pt' => $nama_pt,
        'id_triwulan' => $id_triwulan,
        'id_iku' => $id_iku,
        'ppks' => $ppks,
        'narkoba' => $narkoba,
        'korupsi' => $korupsi,
        'bentuk_ppks' => $bentuk_ppks,
        'bentuk_korupsi' => $bentuk_korupsi,
        'bentuk_narkoba' => $bentuk_narkoba,
        );
  
    $this->m_umum->input_data($datakib,'sakip_iku6');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/iku6/".$id_iku);
              }
           
    }
 function update_iku6()
     {
     $id=$this->input->post('id_iku');
     $id_iku6=$this->input->post('id_iku6');
     $bentuk_ppks=$this->input->post('bentuk_ppks');
     $bentuk_narkoba=$this->input->post('bentuk_narkoba');
     $bentuk_korupsi=$this->input->post('bentuk_korupsi');

                        
       if (!empty($_FILES['ppks']['name'])) {
     $ppks = $this->uploadppks();
      } else {
          $ppks= $this->input->post("old_ppks");
      }

       if (!empty($_FILES['narkoba']['name'])) {
     $narkoba = $this->uploadnarkoba();
      } else {
          $narkoba= $this->input->post("old_narkoba");
      }

       if (!empty($_FILES['korupsi']['name'])) {
     $korupsi = $this->uploadkorupsi();
      } else {
          $korupsi= $this->input->post("old_korupsi");
      }
    $data_update = array(
    
        'id_iku6' => $id_iku6,
        'ppks' => $ppks,
        'narkoba' => $narkoba,
        'bentuk_narkoba' => $bentuk_narkoba,
        'bentuk_korupsi' => $bentuk_korupsi,
        'bentuk_ppks' => $bentuk_ppks,
        'korupsi' => $korupsi
        );
   $where = array('id_iku6' => $id_iku6);
        $res = $this->m_umum->UpdateData('sakip_iku6', $data_update, $where);
     $notif = " Update data berhasil";
              $this->session->set_flashdata('success', $notif);
               redirect(base_url()."app/iku6/".$id);
    }
  function cetak_iku6($id_iku)
{
 
  $data['dt_iku6']=$this->m_sakip->get_iku6($id_iku);
  $this->load->view('sakip/laporan/cetak_iku6',$data);
  
}
function delete_iku6($id,$id_iku)
{
 
    $this->m_umum->hapus('sakip_iku6','id_iku6',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku6/".$id_iku);
 
}
function iku7($id_iku)
{
  
 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_iku7'=> $this->m_sakip->get_iku7($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku7', $data);
     
}
function simpan_iku7() { 
  $id_triwulan=$this->input->post('id_triwulan');
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $id_iku=$this->input->post('id_iku');

  $query1 = $this->db->query("SELECT 
* from sakip_mhs_pres where 
nipd NOT IN(
SELECT nipd  FROM sakip_iku7)
and thn_prestasi NOT IN(
SELECT thn_prestasi  FROM sakip_iku7)");
   
  foreach ($query1->result() as $a) {
    
    $sql1 = "insert into sakip_iku7 (id_iku7,kode_pt,nama_pt,nipd,nm_pd,nm_prestasi,nm_tkt_prestasi,nm_jns_prestasi,peringkat,penyelenggara,thn_prestasi,id_iku,id_triwulan,status_iku,catatan) values (NULL,'$a->npsn','$a->nm_lemb','$a->nipd','".addslashes($a->nm_pd)."','".addslashes($a->nm_prestasi)."','$a->nm_tkt_prestasi','$a->nm_jns_prestasi','$a->peringkat','".addslashes($a->penyelenggara)."','$a->thn_prestasi','$id_iku','$id_triwulan','0','')";
    $this->db->query($sql1);
                }
                $this->db->query("UPDATE sakip_iku7
SET  bobot =  CASE  
                        WHEN nm_tkt_prestasi ='Nasional' THEN 0.50
                        WHEN nm_tkt_prestasi ='Internasional' THEN 0.75
                        WHEN nm_tkt_prestasi ='Propinsi' THEN 0.25
                     
                        end
                       ");
                
                $notif = "Tambah Data Berhasil";
                $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/iku7/".$id_iku);
  
  }
  function update_iku7(){
        $id_iku7 = $this->input->post('id_iku7');
        $id_iku = $this->input->post('id_iku');
        $old = $this->input->post('old_file');
            
            if (!empty($_FILES["file"]["name"])) {
                  $file = $this->uploadFile();
                  unlink("./upload/$old");
                } else {
                    $file = $old;
                }
            $data_update = array(
                'file' => $file
                );
                $where = array('id_iku7' => $id_iku7);
                $res = $this->m_umum->UpdateData('sakip_iku7', $data_update, $where);
                if($res>=1){
                   
                    $notif = "Bukti Dukung berhasil di tambah";
            $this->session->set_flashdata('update', $notif);
              redirect(base_url()."app/iku7/".$id_iku);
                }else{
                    echo "<h1>GAGAL</h1>";
                }
            }

function delete_iku7($id,$id_iku)
{
 
    $this->m_umum->hapus('sakip_iku7','id_iku7',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku7/".$id_iku);
 
}
  function cetak_iku7($id_iku)
  {
  
    $data['dt_iku7']=$this->m_sakip->get_iku7($id_iku);
    $this->load->view('sakip/laporan/cetak_iku3',$data);
    
  }
function iku8($id_iku)
{
  
 $tahun=$this->session->userdata('tahun');
  
  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_pts'=> $this->m_sakip->get_pts_iku8(),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_iku8'=> $this->m_sakip->get_iku8($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),

    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );
  
  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku8', $data);
     
}
function simpan_iku8() { 
  
    $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_iku8',$kode_unik);
  $this->form_validation->set_rules(
    'kode_pt', 'Kode PT',
    'required|is_unique[sakip_iku8.kode_pt]');
  $id=$this->input->post('id_iku');
  if($this->form_validation->run() === FALSE){
    $notif = "PTS Sudah Ada/Sudah Menjadi Capaian ditahun Sebelumnya";
    $this->session->set_flashdata('delete', $notif);
  redirect(base_url()."app/iku8/".$id);
  }
  else
  {
      
      $this->m_umum->set_data("sakip_iku8");
      $notif = "Tambah Data Berhasil";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku8/".$id);
  }

}
function cetak_iku8($id_iku)
{
 
  $data['dt_iku8']=$this->m_sakip->get_iku8($id_iku);
  $this->load->view('sakip/laporan/cetak_iku8',$data);
  
}
function update_iku8()
	{
   
		$this->form_validation->set_rules('id_iku8','id_iku8','required');
    $id=$this->input->post('id_iku');
		if($this->form_validation->run() === FALSE)
    redirect(base_url()."app/iku8/".$id);
		else
		{
			$this->m_umum->update_data("sakip_iku8");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/iku8/".$id);
		}
   
	}
function delete_iku8($id,$id_iku)
{
 
    $this->m_umum->hapus('sakip_iku8','id_iku8',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku8/".$id_iku);
 
}
function iku9($id_iku)
{

 $tahun=$this->session->userdata('tahun');
  
  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_pts'=> $this->m_sakip->get_pts_iku9(),
    'dt_iku9'=> $this->m_sakip->get_iku9($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),

    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );
  
  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku9', $data);
      
}
function simpan_iku9() { 

    $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_iku9',$kode_unik);
  $this->form_validation->set_rules(
    'kode_pt', 'Kode PT',
    'required|is_unique[sakip_iku9.kode_pt]');
  $id=$this->input->post('id_iku');
  if($this->form_validation->run() === FALSE){
    $notif = "PTS Sudah Ada/Sudah Menjadi Capaian ditahun Sebelumnya";
    $this->session->set_flashdata('delete', $notif);
  redirect(base_url()."app/iku9/".$id);
  }
  else
  {
      
      $this->m_umum->set_data("sakip_iku9");
      $notif = "Tambah Data Berhasil";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku9/".$id);
  }

}
function update_iku9()
	{
   
		$this->form_validation->set_rules('id_iku9','id_iku9','required');
    $id=$this->input->post('id_iku');
		if($this->form_validation->run() === FALSE)
    redirect(base_url()."app/iku9/".$id);
		else
		{
			$this->m_umum->update_data("sakip_iku9");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/iku9/".$id);
		}
    
	}
  function cetak_iku9($id_iku)
{
 
  $data['dt_iku9']=$this->m_sakip->get_iku9($id_iku);
  $this->load->view('sakip/laporan/cetak_iku9',$data);
  
}
function delete_iku9($id,$id_iku)
{
  
    $this->m_umum->hapus('sakip_iku9','id_iku9',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku9/".$id_iku);
 
}
function iku10($id_iku)
{

 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_pts'=> $this->m_sakip->get_pts(),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_iku10'=> $this->m_sakip->get_iku10($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku10', $data);
    
}

function simpan_iku10(){
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_iku10',$kode_unik);
    $this->form_validation->set_rules('predikat_sakip','predikat_sakip','required');
    $id_iku=$this->input->post('id_iku');
    $predikat_sakip=$this->input->post('predikat_sakip');
    $id_triwulan=$this->input->post('id_triwulan');
 $file = $this->uploadFile();
       if($this->form_validation->run() === FALSE) {
  redirect(base_url()."app/iku10/".$id_iku);
  }    else{


    $datakib = array(
    
        'predikat_sakip' => $predikat_sakip,
        'id_triwulan' => $id_triwulan,
        'id_iku' => $id_iku,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_iku10');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/iku10/".$id_iku);
              }
            
    }
function update_iku10()
	{
   
		$this->form_validation->set_rules('id_iku10','id_iku10','required');
    $id=$this->input->post('id_iku');
		if($this->form_validation->run() === FALSE)
    redirect(base_url()."app/iku10/".$id);
		else
		{
			$this->m_umum->update_data("sakip_iku10");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/iku10/".$id);
		}
    
	}
  function cetak_iku10($id_iku)
  {
   
    $data['dt_iku10']=$this->m_sakip->get_iku10($id_iku);
    $this->load->view('sakip/laporan/cetak_iku10',$data);
    
  }
  function delete_iku10($id,$id_iku)
{
 
    $this->m_umum->hapus('sakip_iku10','id_iku10',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku10/".$id_iku);
 
}
function iku11($id_iku)
{
  
 $tahun=$this->session->userdata('tahun');

  $data = array(
    'id'=>$id_iku,
    'd'=> $this->m_sakip->m_iku($id_iku),
    'dt_bukti'=> $this->m_sakip->get_bukti($id_iku),
    'dt_iku11'=> $this->m_sakip->get_iku11($id_iku),
    'dt_tw'=> $this->m_sakip->get_triwulan(),
    'judul' => 'Capaian Kinerja', 
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku11', $data);
     
}

function simpan_iku11(){
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_iku11',$kode_unik);
    $this->form_validation->set_rules('nilai_rka','nilai_rka','required');
    $id_iku=$this->input->post('id_iku');
    $nilai_rka=$this->input->post('nilai_rka');
    $id_triwulan=$this->input->post('id_triwulan');
 $file = $this->uploadFile();
       if($this->form_validation->run() === FALSE) {
  redirect(base_url()."app/iku11/".$id_iku);
  }    else{


    $datakib = array(
    
        'nilai_rka' => $nilai_rka,
        'id_triwulan' => $id_triwulan,
        'id_iku' => $id_iku,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_iku11');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
              redirect(base_url()."app/iku11/".$id_iku);
              }
           
    }
function update_iku11()
	{
      
		$this->form_validation->set_rules('id_iku11','id_iku11','required');
    $id=$this->input->post('id_iku');
		if($this->form_validation->run() === FALSE)
    redirect(base_url()."app/iku11/".$id);
		else
		{
			$this->m_umum->update_data("sakip_iku11");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/iku11/".$id);
		}
   
	}
  function delete_iku11($id,$id_iku)
{
 
    $this->m_umum->hapus('sakip_iku11','id_iku11',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/iku11/".$id_iku);
 
}
function cetak_iku11($id_iku)
{
 
  $data['dt_iku11']=$this->m_sakip->get_iku11($id_iku);
  $this->load->view('sakip/laporan/cetak_iku11',$data);
  
}
function tahun()
{
 
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Tahun SAKIP',
      'dt_tahun'=> $this->m_sakip->get_data('tahun_sakip'),
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/sakip_tahun', $data);
     
}
function simpan_tahun() { 
    
    $this->db->set('id_tahun', 'UUID()', FALSE);
    $this->form_validation->set_rules('tahun','tahun','required');
    if($this->form_validation->run() === FALSE)
    redirect('app/tahun');
    else
    {
        
        $this->m_umum->set_data("tahun_sakip");
        $notif = "Tambah Data Berhasil";
        $this->session->set_flashdata('success', $notif);
       redirect('app/tahun');
    }
 
}
function pk()
{
  
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'File Perjanjian Kinerja',
      'dt_pk'=> $this->m_sakip->get_data('sakip_pk'),
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/pk', $data);
      
}
 function iku()
{
  
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Indikator Kinerja Utama LLDIKTI XI',
      'dt_iku'=> $this->m_sakip->get_iku(),
      'dt_ikk'=> $this->m_sakip->get_ikk_admin(),
      'dt_bagian'=> $this->m_sakip->get_data('sakip_bagian'),
      'tahun'=> $tahun,
  );  
  $this->template->load('sakip/admin/template', 'sakip/admin/iku', $data);
      
}
function simpan_iku() { 
    
    $this->db->set('id_iku', 'UUID()', FALSE);
    $this->form_validation->set_rules('id_ikk','id_ikk','required');
    if($this->form_validation->run() === FALSE)
    redirect('app/iku');
    else
    {
        
        $this->m_umum->set_data("sakip_iku");
        $notif = "Tambah Data Berhasil";
        $this->session->set_flashdata('success', $notif);
       redirect('app/iku');
    }
 
}
function update_iku()
	{
        
		$this->form_validation->set_rules('id_iku','id_iku','required');
		if($this->form_validation->run() === FALSE)
    redirect('app/iku');
		else
		{
			$this->m_umum->update_data("sakip_iku");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect('app/iku');
		}
    
	}
  function delete_tahun($id)
{
  
    $this->m_umum->hapus('tahun_sakip','id_tahun',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
    redirect('app/tahun');
  
}
function delete_iku($id)
{
  
    $this->m_umum->hapus('sakip_iku','id_iku',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
    redirect('app/iku');
  
}
 function target_kinerja()
{
  
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Target Perjanjian Kinerja',
      'dt_sasaran'=> $this->m_sakip->get_sk(),
      'tahun'=> $tahun,
  );	
  $this->template->load('sakip/admin/template', 'sakip/admin/sasaran_kegiatan', $data);
  
}

 function simpan_sasaran_kegiatan() { 
    
          $tahun=$this->session->userdata('tahun');
$this->db->set('id_sasaran_kegiatan', 'UUID()', FALSE);
$this->db->set('tahun',$tahun);
    $this->form_validation->set_rules('sasaran_kegiatan','sasaran_kegiatan','required');
    if($this->form_validation->run() === FALSE)
    redirect('app/target_kinerja');
    else
    {
        
        $this->m_umum->set_data("sakip_sasaran_kegiatan");
        $notif = "Tambah Data Berhasil";
        $this->session->set_flashdata('success', $notif);
        redirect('app/target_kinerja');
    }

}
function update_sasaran_kegiatan()
	{
        
		$this->form_validation->set_rules('id_sasaran_kegiatan','id_sasaran_kegiatan','required');
		if($this->form_validation->run() === FALSE)
        redirect('app/target_kinerja');
		else
		{
			$this->m_umum->update_data("sakip_sasaran_kegiatan");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
			redirect('app/target_kinerja');
		}
    
	}
 function delete_sasaran_kegiatan($id=NULL)
	{
     
		$this->m_umum->hapus('sakip_sasaran_kegiatan','id_sasaran_kegiatan',$id);
		 $notif = " Data berhasil dihapuskan";
            $this->session->set_flashdata('delete', $notif);
		redirect('app/target_kinerja');
     
	}
 function error(){
    $this->load->view('errors/html/error_404');  
}
function ikk($id)
{
  
 $tahun=$this->session->userdata('tahun');
  $data = array(
      'judul' => 'Target Perjanjian Kinerja',
      'id' => $id,
      'dt_ikk'=> $this->m_sakip->get_ikk($id),
      'tahun'=> $tahun,
  );	
  $this->template->load('sakip/admin/template', 'sakip/admin/ikk', $data);
  
}

function simpan_ikk() { 
    
    $this->db->set('id_ikk', 'UUID()', FALSE);
    $this->form_validation->set_rules('ikk','ikk','required');
    $id=$this->input->post('id_sasaran_kegiatan');
    if($this->form_validation->run() === FALSE)
    redirect('app/target_kinerja');
    else
    {
        
        $this->m_umum->set_data("sakip_ikk");
        $notif = "Tambah Data Berhasil";
        $this->session->set_flashdata('success', $notif);
        redirect(base_url()."app/ikk/".$id);
    }
	
}

function update_ikk()
	{
        
		$this->form_validation->set_rules('id_ikk','id_ikk','required');
        $id=$this->input->post('id_sasaran_kegiatan');
		if($this->form_validation->run() === FALSE)
        redirect('app/target_kinerja');
		else
		{
			$this->m_umum->update_data("sakip_ikk");
			 $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
            redirect(base_url()."app/ikk/".$id);
		}
    
	}

function delete_ikk($id=NULL,$id_sk)
{
  
    $this->m_umum->hapus('sakip_ikk','id_ikk',$id);
     $notif = " Data berhasil dihapuskan";
        $this->session->set_flashdata('delete', $notif);
        redirect(base_url()."app/ikk/".$id_sk);
        
}
 function kirim_analisa($id_analisa,$id_iku){
      $this->db->query("update sakip_analisa set status_analisa=1 where id_analisa='$id_analisa'");
      $notif = " Data Analisa IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/analisa_capaian_kinerja/".$id_iku);
  }
 function kirim_iku2(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku2 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku2/".$id_iku);
  }
  function kirim_iku3(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku3 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku3/".$id_iku);
  }
  function kirim_iku4(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku4 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku4/".$id_iku);
  }
  function kirim_iku5(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku5 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku5/".$id_iku);
  }
  function kirim_iku6(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku6 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku6/".$id_iku);
  }
  function kirim_iku7(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku7 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku7/".$id_iku);
  }
  function kirim_iku8(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku8 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku8/".$id_iku);
  }
  function kirim_iku9(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku9 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku9/".$id_iku);
  }
  function kirim_iku10(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku10 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku10/".$id_iku);
  }
  function kirim_iku11(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku11 set status_iku=1 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku11/".$id_iku);
  }


function valid_iku2(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku2 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku2/".$id_iku);
  }
  function valid_iku3(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku3 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku3/".$id_iku);
  }
  function valid_iku4(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku4 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku4/".$id_iku);
  }
  function valid_iku5(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku5 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku5/".$id_iku);
  }
  function valid_iku6(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku6 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku6/".$id_iku);
  }
  function valid_iku7(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku7 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku7/".$id_iku);
  }
  function valid_iku8(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku8 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku8/".$id_iku);
  }
  function valid_iku9(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku9 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku9/".$id_iku);
  }
  function valid_iku10(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku10 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku10/".$id_iku);
  }
  function valid_iku11(){
    $id_triwulan=$this->input->post('id_triwulan');
    $id_iku=$this->input->post('id_iku');
      $this->db->query("update sakip_iku11 set status_iku=3 where id_triwulan='$id_triwulan' and id_iku='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku11/".$id_iku);
  }
  function validasi_iku2()
  {
        
    $this->form_validation->set_rules('id_iku2','id_iku2','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku2/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku2");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku2/".$id);
    }
    
  }
  function validasi_iku4()
  {
        
    $this->form_validation->set_rules('id_iku4','id_iku4','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku4/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku4");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku4/".$id);
    }
    
  }
  function validasi_iku5()
  {
        
    $this->form_validation->set_rules('id_iku5','id_iku5','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku5/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku5");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku5/".$id);
    }
    
  }
  function validasi_iku6()
  {
        
    $this->form_validation->set_rules('id_iku6','id_iku6','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku6/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku6");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku6/".$id);
    }
    
  }
  function validasi_iku7()
  {
        
    $this->form_validation->set_rules('id_iku7','id_iku7','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku7/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku7");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku7/".$id);
    }
    
  }
  function validasi_iku8()
  {
        
    $this->form_validation->set_rules('id_iku8','id_iku8','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku8/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku8");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku8/".$id);
    }
    
  }
  function validasi_iku9()
  {
        
    $this->form_validation->set_rules('id_iku9','id_iku9','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku9/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku9");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku9/".$id);
    }
    
  }
   function validasi_iku10()
  {
        
    $this->form_validation->set_rules('id_iku10','id_iku10','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku10/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku10");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku10/".$id);
    }
    
  }
   function validasi_iku11()
  {
        
    $this->form_validation->set_rules('id_iku11','id_iku11','required');
    $this->form_validation->set_rules('status_iku', 'status_iku');
    $id=$this->input->post('id_iku');
    if($this->form_validation->run() === FALSE) {
   redirect(base_url()."app/iku11/".$id);
      }
    else
    {
      $this->m_umum->update_data("sakip_iku11");
       $notif = " Data berhasil diupdate";
            $this->session->set_flashdata('update', $notif);
           redirect(base_url()."app/iku11/".$id);
    }
    
  }
function simpan_pk(){
   
  $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
  $this->db->set('id_pk',$kode_unik);
    $tahun=$this->input->post('tahun');
 $file = $this->uploadFile();
                    
    $datakib = array(
    
        'tahun' => $tahun,
        'file' => $file
        );
  
    $this->m_umum->input_data($datakib,'sakip_pk');
     $notif = " Data berhasil ditambahkan";
              $this->session->set_flashdata('success', $notif);
                 redirect('app/pk');
              
    }
    function delete_pk($id=NULL)
  {
     
    $this->m_umum->hapus('sakip_pk','id_pk',$id);
     $notif = " Data berhasil dihapuskan";
            $this->session->set_flashdata('delete', $notif);
    redirect('app/pk');
     
  }
  function send_iku1($id_iku,$id){
 
      $this->db->query("update sakip_iku1 set status_iku=1 where id_iku1='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku1/".$id);
  }
function send_iku2($id_iku,$id){
 
      $this->db->query("update sakip_iku2 set status_iku=1 where id_iku2='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku2/".$id);
  }
  function send_iku4($id_iku,$id){
 
      $this->db->query("update sakip_iku4 set status_iku=1 where id_iku4='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku4/".$id);
  }
function send_iku5($id_iku,$id){
 
      $this->db->query("update sakip_iku5 set status_iku=1 where id_iku5='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku5/".$id);
  }
  function send_iku6($id_iku,$id){
 
      $this->db->query("update sakip_iku6 set status_iku=1 where id_iku6='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku6/".$id);
  }
  function send_iku7($id_iku,$id){
 
      $this->db->query("update sakip_iku7 set status_iku=1 where id_iku7='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku7/".$id);
  }
  function send_iku8($id_iku,$id){
 
      $this->db->query("update sakip_iku8 set status_iku=1 where id_iku8='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku8/".$id);
  }
  function send_iku9($id_iku,$id){
 
      $this->db->query("update sakip_iku9 set status_iku=1 where id_iku9='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku9/".$id);
  }
  function send_iku10($id_iku,$id){
 
      $this->db->query("update sakip_iku10 set status_iku=1 where id_iku10='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku10/".$id);
  }
  function send_iku11($id_iku,$id){
 
      $this->db->query("update sakip_iku11 set status_iku=1 where id_iku11='$id_iku' ");
      $notif = " Data IKU berhasil dikirim";
      $this->session->set_flashdata('success', $notif);
      redirect(base_url()."app/iku11/".$id);
  }

}

  ?>