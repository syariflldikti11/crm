<?php

class Login_sakip extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->model('m_sakip_login');
    }
 
    function index(){
        
        $data = array(
            'judul' => 'Halaman Login',
            'menu'=> 'login',
            'action' => 'login_sakip/auth',
            'dt_tahun'=> $this->m_umum->get_data('tahun_sakip')
        );  
        $this->template->load('sakip/login/template', 'sakip/login/login_form', $data);
    }

    function auth(){
        $username=htmlspecialchars($this->input->post('username',TRUE),ENT_QUOTES);
        $password=htmlspecialchars($this->input->post('password',TRUE),ENT_QUOTES);
        $tahun=$this->input->post('tahun');
        $cek_admin=$this->m_sakip_login->auth_admin($username);
        $cek_user=$this->m_sakip_login->auth_user($username,$password);
        if($cek_admin->num_rows() > 0){ 
                        $data=$cek_admin->row_array();
                $this->session->set_userdata('masuk',TRUE);
   if($data['level']=='1' && password_verify($password, $data['password'])){ 
                    $this->session->set_userdata('akses','1');
                       $this->session->set_userdata('ses_id',$data['username']);
                            $this->session->set_userdata('tahun',$tahun);
                    redirect('app');
                 }
                  if($data['level']=='3' && password_verify($password, $data['password'])){ 
                    $this->session->set_userdata('akses','3');
                       $this->session->set_userdata('ses_id',$data['username']);
                            $this->session->set_userdata('tahun',$tahun);
                    redirect('validator');
                 }
                 if($data['level']=='4' && password_verify($password, $data['password'])){ 
                    $this->session->set_userdata('akses','4');
                       $this->session->set_userdata('ses_id',$data['username']);
                            $this->session->set_userdata('tahun',$tahun);
                    redirect('pimpinan');
                 }
        }
        if($cek_user->num_rows() > 0){ 
            $datauser=$cek_user->row_array();
            $this->session->set_userdata('masuk',TRUE);
             if($datauser['level']=='1'){ 
                           $this->session->set_userdata('akses','2');
                           $this->session->set_userdata('username',$datauser['username']);
                           $this->session->set_userdata('jenis',$datauser['jenis']);
                $this->session->set_userdata('ses_id',$datauser['bagian']);
                $this->session->set_userdata('id',$datauser['id_bagian']);
                $this->session->set_userdata('tahun',$tahun);
                redirect('pj'); 
}

    }
        else {
            $notif = "username/Password Salah";
            $this->session->set_flashdata('gagal', $notif);
            redirect('login_sakip');
        }
    }

    function logout(){
        $this->session->sess_destroy();
        redirect(base_url('login_sakip'));
    }
 
}

 