<div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title"><?= $judul ?></h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     Renaksi
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                 d-md-flex
              "
            >
              <div class="d-flex">
               
                <button class="btn btn-warning">
               
                  Tahun <?= $tahun; ?>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
<div class="row">
    <div class="col-12">
      <div class="card">
      
        <div class="card-body">
         
          <div class="table-responsive">
            <table
              id="zero_config"
              class="table table-striped table-bordered"
            >
            <thead class="bg-info text-white">
                <tr>
                  <th><div align="center">No</div></th>
                  <th><div align="center">IKK</div></th>
                  <th><div align="center">Target</div></th>
                  <th><div align="center">TW1</div></th>
                  <th><div align="center">TW2</div></th>
                  <th><div align="center">TW3</div></th>
                  <th><div align="center">TW4</div></th>
                        <th ><div align="center">Opsi</div></th>
</tr>
              </thead>
             
                
           
              <tbody>
                <?php
                $no=1;
                foreach ($dt_renaksi as $d): ?>
                <tr>
                  <td><div align="center">
                    <?= $no++; ?>
                  </div></td>
                  <td>
                    
                    <div align="left">
                      <?= $d->ikk; ?>
                    </div></td>
                  <td><div align="center">
                    <?= $d->target; ?>
                  </div></td>
                  <td><div align="center"><?= $d->tw1_renaksi; ?></div></td>
                  <td><div align="center"><?= $d->tw2_renaksi; ?></div></td>
                  <td><div align="center"><?= $d->tw3_renaksi; ?></div></td>
                  <td><div align="center"><?= $d->tw4_renaksi; ?></div></td>
                    <td><div align="center"> <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Renaksi" href="javascript:;"
                           data-bs-toggle="modal" data-bs-target="#bs-edit-data"   
                              data-id="<?= $d->id_ikk ?>"
                            
                              data-tw1_renaksi="<?= $d->tw1_renaksi ?>"
                            
                              data-tw2_renaksi="<?= $d->tw2_renaksi ?>"
                             
                              data-tw3_renaksi="<?= $d->tw3_renaksi ?>"
                             
                              data-tw4_renaksi="<?= $d->tw4_renaksi ?>"
                              > 
                              <i data-feather="target" class="feather-icon"></i
                  > </a></div></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
                

              
  <div
                        id="bs-edit-data"
                        class="modal fade"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-md"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myModalLabel">
                           Input Rencana Aksi Triwulan
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">

                         <?php  
             echo validation_errors();                       
    echo form_open('app/update_renaksi'); ?>
                   <input
                            type="hidden"
                            name="id_ikk"
                            id="id"
                            required
                          />
                   <div class="card-body bg-light">
                  

                              <div class="mb-3">
                                <label for="emailaddress">TW I Renaksi</label>
                                <input
                                  class="form-control"
                                  type="text" name="tw1_renaksi"
                                  id="tw1_renaksi"
                                  required
                                 
                                />
                              </div>
                </div>
                <hr>
                <div class="card-body bg-white">
           

                              <div class="mb-3">
                                <label for="emailaddress">TW II Renaksi</label>
                                <input
                                  class="form-control"
                                  type="text"
                                  required
                                  name="tw2_renaksi"
                                  id="tw2_renaksi"
                                 
                                 
                                />
                              </div>
                </div>
                
                <hr>

                <div class="card-body bg-light">
                             
                              <div class="mb-3">
                                <label for="emailaddress">TW III Renaksi</label>
                                <input
                                  class="form-control"
                                  type="text"
                                  name="tw3_renaksi"
                                  id="tw3_renaksi"
                                  required
                                 
                                />
                              </div>
                </div>
                <hr>
                <div class="card-body bg-white">
                             

                              <div class="mb-3">
                                <label for="emailaddress">TW IV Renaksi</label>
                                <input
                                  class="form-control"
                                  type="text"
                                  name="tw4_renaksi"
                                  id="tw4_renaksi"
                                  required="isi"
                                 
                                />
                              </div>
                </div>
                
                            </div>
                            <div class="modal-footer">
                            <input type="submit" name="submit"  class="btn btn-info btn-pill" value="Submit">
                              <button
                                type="button"
                                class="btn btn-danger btn-pill"
                                data-bs-dismiss="modal">
                                Close
                              </button>
                            </div>
                </form>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>



                      <script>
    $(document).ready(function() {
      
        $('#bs-edit-data').on('show.bs.modal', function (event) {
            var div = $(event.relatedTarget)
            var modal   = $(this)

            // Isi nilai pada field
            modal.find('#id').attr("value",div.data('id'));
           
            modal.find('#tw1_renaksi').attr("value",div.data('tw1_renaksi'));
           
            modal.find('#tw2_renaksi').attr("value",div.data('tw2_renaksi'));
           
            modal.find('#tw3_renaksi').attr("value",div.data('tw3_renaksi'));
          
            modal.find('#tw4_renaksi').attr("value",div.data('tw4_renaksi'));
        });
    });
</script>