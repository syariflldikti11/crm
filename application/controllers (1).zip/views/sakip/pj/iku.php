<div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title"><?= $judul ?></h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                    IKU LLDIKTI 11
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                 d-md-flex
              "
            >
              <div class="d-flex">
               
                <button class="btn btn-warning">
               
                  Tahun <?= $tahun; ?>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="border-bottom title-part-padding">
          <h4 class="card-title mb-0"></h4> 
        </div>
        <div class="card-body">
         
          <div class="table-responsive">
            <table
              id="zero_config"
              class="table table-striped table-bordered"
            >
            <thead class="bg-info text-white">
                <tr>
                  <th><div align="center">No</div></th>
                  <th><div align="left">IKK</div></th>
                  <th><div align="left">IKU</div></th>
                  <th><div align="left">Penanggung Jawab</div></th>
                  
                </tr>
              </thead>
              <tbody>
                <?php
                $no=1;
                foreach ($dt_iku as $d): ?>
                <tr>
                  <td><div align="center">
                    <?= $no++; ?>
                  </div></td>
                  <td>
                    <div align="left">
                      <?= $d->ikk; ?>
                    </div></td>
                  <td>
                    <div align="left">
                      <?= $d->iku; ?>
                    </div></td>
                  <td>
                    <div align="left">
                    <?php if($d->id_bagian=='') {
                    echo "Seluruh Pemberi Layanan";
                    
                  }
                  else
                  {
                    echo $d->bagian;
                  }
                  ?>
                    </div></td>
                   
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>



<div>