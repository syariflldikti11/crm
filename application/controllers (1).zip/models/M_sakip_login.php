<?php
class M_sakip_login extends CI_Model{

	function auth_admin($username){
		$this->db->select('*');
		$this->db->from('sakip_admin');
		$this->db->where('username',$username);
		$this->db->limit(1);
		$query = $this->db->get();
		return $query;
		}
		function auth_user($username,$password){
			$query=$this->db->query("SELECT * FROM sakip_user join sakip_bagian on sakip_user.id_bagian=sakip_bagian.id_bagian  WHERE username='$username' AND password=sha1('$password') LIMIT 1");
			return $query;
		}

 
 
}