<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_sakip extends CI_Model{
   public function hitung_iku1()
{   $tahun=$this->session->userdata('tahun');
		$this->db->select('*');
		$this->db->from('sakip_iku1');
		  $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku1.id_iku','');
		$this->db->where('status_iku=1');
		$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
  function get_row_view_dokumen($id_usulan_tb)
  {
    $this->db->select('*');
    $this->db->from('usulan_tb');
    $this->db->where('id_usulan_tb', $id_usulan_tb);
    $query = $this->db->get();
    return $query->row();
  }
function cek_usulan_tb($id_usulan_tb)
     {    
      $query =$this->db->query("
                    SELECT status_usulan from usulan_tb
                    
                    WHERE id_usulan_tb='$id_usulan_tb' 
                ");
       return $query->row();
    }
    function cek_jumlah($id_usulan_tb)
     {    
      $query =$this->db->query("
                    SELECT count(id_usulan_tb) as jumlah from detail_usulan_tb
                    
                    WHERE id_usulan_tb='$id_usulan_tb' 
                ");
       return $query->row();
    }
      function cek_valid($id_usulan_tb)
     {    
      $query =$this->db->query("
                    SELECT count(id_usulan_tb) as valid from detail_usulan_tb
                    
                    WHERE id_usulan_tb='$id_usulan_tb' and status_detail_usulan=3 
                ");
       return $query->row();
    }
    function cek_kembali($id_usulan_tb)
     {    
      $query =$this->db->query("
                    SELECT count(id_usulan_tb) as kembali from detail_usulan_tb
                    
                    WHERE id_usulan_tb='$id_usulan_tb' and status_detail_usulan=2 
                ");
       return $query->row();
    }
public function hitung_iku2()
{   $tahun=$this->session->userdata('tahun');
		$this->db->select('*');
		$this->db->from('sakip_iku2');
		  $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku2.id_iku','');
		$this->db->where('status_iku=1');
			$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
public function hitung_proker_tb()
{  
 $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('usulan_tb');
    $this->db->where('status_usulan=1');
      $this->db->where('tahun_proker',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
public function hitung_proker_td()
{  
 $tahun=$this->session->userdata('tahun');
 $tahuntd=$tahun+1;
    $this->db->select('*');
    $this->db->from('usulan_tb');
    $this->db->where('status_usulan=1');
      $this->db->where('tahun_proker',$tahuntd);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
public function hitung_iku3()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku3');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku3.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku4()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku4');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku4.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku5()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku5');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku5.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku6()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku6');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku6.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku7()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku7');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku7.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku8()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku8');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku8.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku9()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku9');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku9.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku10()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku10');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku10.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_iku11()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku11');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku11.id_iku','');
    $this->db->where('status_iku=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

 public function hitung_kembali_iku1()
{   $tahun=$this->session->userdata('tahun');
		$this->db->select('*');
		$this->db->from('sakip_iku1');
		  $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku1.id_iku','');
		$this->db->where('status_iku=2');
		$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku2()
{   $tahun=$this->session->userdata('tahun');
		$this->db->select('*');
		$this->db->from('sakip_iku2');
		  $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku2.id_iku','');
		$this->db->where('status_iku=2');
			$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku3()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku3');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku3.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku4()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku4');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku4.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku5()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku5');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku5.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku6()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku6');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku6.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku7()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku7');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku7.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku8()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku8');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku8.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku9()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku9');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku9.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku10()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku10');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku10.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}

public function hitung_kembali_iku11()
{   $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_iku11');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_iku11.id_iku','');
    $this->db->where('status_iku=2');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
public function hitung_analisa()
{
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_analisa');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_analisa.id_iku','');
    $this->db->where('status_analisa=1');
    	$this->db->where('tahun_iku',$tahun);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
public function hitung_kembali_analisa()
{
    $id=$this->session->userdata('id');
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('sakip_analisa');
      $this->db->join('sakip_iku','sakip_iku.id_iku=sakip_analisa.id_iku','');
    $this->db->where('status_analisa=2');
    	$this->db->where('tahun_iku',$tahun);
    		$this->db->where('id_bagian',$id);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
		 function get_pts()
		 {		
			
			 $this->db->select('*');
			$this->db->from('sakip_pts');
			$this->db->where('status_pt="A"');
			$query = $this->db->get();
			return $query->result();
		 }
		 function get_pk()
		 {		
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_pk');
			$this->db->where('tahun',$tahun);
			$query = $this->db->get();
			return $query->row();
		 }
		 function get_pts_all()
		 {		
			
			$this->db->select('*');
			$this->db->from('sakip_pts');
			$this->db->where('status_pt !="H"');
			$query = $this->db->get();
			return $query->result();
		 }

		 function  get_pts_iku2()
		 {		
			
			$this->db->select('*');
			$this->db->from('sakip_akred_pt');
			$query = $this->db->get();
			return $query->result();
		 }

		 function  get_pts_iku9()
		 {		
			
			$query=$this->db->query("select
			kode_pt,
			nama_pt,
			count(nama_prodi) as total
			from sakip_prodi
      where jenjang_prodi IN('S1','D4','D3','D2','D1')
			GROUP by nama_pt");
			return $query->result();
		 }
		  function  get_pts_iku8()
		 {		
			
			$query=$this->db->query("select
			*
			from sakip_jumlah_dosen");
			return $query->result();
		 }
     function cek_belum_valid($id_usulan_tb)
     {    
      $queryy=$this->db->query("SELECT * from detail_usulan_tb WHERE id_usulan_tb='$id_usulan_tb' and status_detail_usulan=1;");
      return $queryy;
      
     }
		 function cek_detail_usulan_tb($id_usulan_tb)

     {
   
       return $this->db->get_where('detail_usulan_tb',array('id_usulan_tb'=>$id_usulan_tb));
   
     }
     function cek_histori_detail_usulan_tb($id_usulan_tb)

     {
   
       return $this->db->get_where('histori_detail_usulan_tb',array('id_usulan_tb'=>$id_usulan_tb));
   
     }

      function get_total_anggaran($id_usulan_tb)
     {    
      $queryy=$this->db->query("SELECT sum(anggaran) as total_anggaran from detail_usulan_tb WHERE id_usulan_tb='$id_usulan_tb' and status_detail_usulan=3;");
      return $queryy;
      
     }
		 
	
		  function get_usulan_tb(){
    $tahun=$this->session->userdata('tahun');
    $id_bagian=$this->session->userdata('id');
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where('a.tahun_proker',$tahun);
    $this->db->where('a.id_bagian',$id_bagian);
    $this->db->order_by('a.tgl_input desc');
    $query = $this->db->get();
        return $query->result();
    }
     function get_usulan_td(){
    $tahun=$this->session->userdata('tahun');
    $tahuntd=$tahun+1;
    $id_bagian=$this->session->userdata('id');
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where('a.tahun_proker',$tahuntd);
    $this->db->where('a.id_bagian',$id_bagian);
    $this->db->order_by('a.tgl_input desc');
    $query = $this->db->get();
        return $query->result();
    }
     function get_proker_tb(){
    $tahun=$this->session->userdata('tahun');

    $id_bagian=$this->session->userdata('id');
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where('a.tahun_proker',$tahun);
    $this->db->where('a.id_bagian',$id_bagian);
    $this->db->where('a.status_usulan',3);
    $query = $this->db->get();
        return $query->result();
    }

    function get_proker_td(){
    $tahun=$this->session->userdata('tahun');
    $tahuntd=$tahun+1;
    $id_bagian=$this->session->userdata('id');
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where('a.tahun_proker',$tahuntd);
    $this->db->where('a.id_bagian',$id_bagian);
    $this->db->where('a.status_usulan',3);

    $query = $this->db->get();
        return $query->result();
    }
     function cetak_proker_tb_pj()
    {
      $tahun=$this->session->userdata('tahun');
       $id_bagian=$this->session->userdata('id');
      $this->db->select('*');
      $this->db->from('detail_usulan_tb a');
      $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
      $this->db->join('sakip_bagian c','c.id_bagian=b.id_bagian','');
      $this->db->join('iku_proker d','b.id_iku_proker=d.id_iku_proker','');
      $this->db->where('a.status_detail_usulan',3);
      $this->db->where('b.status_usulan',3);
     $this->db->where('c.id_bagian',$id_bagian);
        $this->db->where('b.tahun_proker',$tahun);

      $query = $this->db->get();
      return $query->result();
      }
      function cetak_proker_td_pj()
    {
      $tahun=$this->session->userdata('tahun');
      $tahuntd=$tahun+1;
       $id_bagian=$this->session->userdata('id');
      $this->db->select('*');
      $this->db->from('detail_usulan_tb a');
      $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
      $this->db->join('sakip_bagian c','c.id_bagian=b.id_bagian','');
      $this->db->join('iku_proker d','b.id_iku_proker=d.id_iku_proker','');
      $this->db->where('a.status_detail_usulan',3);
      $this->db->where('b.status_usulan',3);
     $this->db->where('c.id_bagian',$id_bagian);
        $this->db->where('b.tahun_proker',$tahuntd);

      $query = $this->db->get();
      return $query->result();
      }
      function get_usulan_tb_validator(){
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where("a.tahun_proker = ".$tahun."  and (a.status_usulan = 1 OR a.status_usulan = 3)");
    $this->db->order_by('a.tgl_kirim desc');
    $query = $this->db->get();
        return $query->result();
    }
     function get_usulan_td_validator(){
    $tahun=$this->session->userdata('tahun');
    $tahuntd=$tahun+1;
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
 $this->db->where("a.tahun_proker = ".$tahuntd."  and (a.status_usulan = 1 OR a.status_usulan = 3)");
    $this->db->order_by('a.tgl_kirim desc');
    $query = $this->db->get();
        return $query->result();
    }
    function get_proker_tb_validator(){
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where('a.tahun_proker',$tahun);
  $this->db->where('a.status_usulan',3);
    $query = $this->db->get();
        return $query->result();
    }
     function get_proker_td_validator(){
    $tahun=$this->session->userdata('tahun');
    $tahuntd=$tahun+1;
    $this->db->select('*');
    $this->db->from('usulan_tb a');
      $this->db->join('iku_proker b','a.id_iku_proker=b.id_iku_proker','');
      $this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','');
    $this->db->where('a.tahun_proker',$tahuntd);
  $this->db->where('a.status_usulan',3);
    $query = $this->db->get();
        return $query->result();
    }

     function get_detail_usulan_tb($id){
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('detail_usulan_tb a');
    $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
     $this->db->where('a.id_usulan_tb',$id);
    $query = $this->db->get();
        return $query->result();
    }
    function get_histori_detail_usulan_tb($id){
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('histori_detail_usulan_tb a');
     $this->db->where('a.id_detail_usulan_tb',$id);
     $this->db->order_by('a.id_histori asc');
    $query = $this->db->get();
        return $query->result();
    }
     function get_detail_proker_tb($id){
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('detail_usulan_tb a');
    $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
     $this->db->where('a.id_usulan_tb',$id);
     $this->db->where('a.status_detail_usulan',3);
    $query = $this->db->get();
        return $query->result();
    }
    function get_detail_usulan_tb_validator($id){
    $tahun=$this->session->userdata('tahun');
    $this->db->select('*');
    $this->db->from('detail_usulan_tb a');
    $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
     $this->db->where('a.id_usulan_tb',$id);
     $this->db->where('a.status_detail_usulan !=0');
    $query = $this->db->get();
        return $query->result();
    }
   
		function get_ikk_admin(){
		$tahun=$this->session->userdata('tahun');
		$this->db->select('*');
		$this->db->from('sakip_ikk a');
        $this->db->join('sakip_sasaran_kegiatan b','a.id_sasaran_kegiatan=b.id_sasaran_kegiatan','');
		$this->db->where('b.tahun',$tahun);
		$this->db->order_by('a.ikk asc');
		$query = $this->db->get();
        return $query->result();
		}
    function get_ikk($id){
		$tahun=$this->session->userdata('tahun');
		$this->db->select('*');
		$this->db->from('sakip_ikk a');
        $this->db->join('sakip_sasaran_kegiatan b','a.id_sasaran_kegiatan=b.id_sasaran_kegiatan','');
		$this->db->where('a.id_sasaran_kegiatan',$id);
		$this->db->order_by('a.ikk asc');
		$query = $this->db->get();
        return $query->result();
		}
		function get_renaksi(){
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_ikk a');
			$this->db->join('sakip_sasaran_kegiatan b','a.id_sasaran_kegiatan=b.id_sasaran_kegiatan','');
		
			$this->db->where('b.tahun',$tahun);
			$this->db->order_by('a.no_ikk asc');
			$query = $this->db->get();
			return $query->result();
			}
        function cetak_proker_tb()
    {
      $tahun=$this->session->userdata('tahun');
      $this->db->select('*');
      $this->db->from('detail_usulan_tb a');
      $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
      $this->db->join('sakip_bagian c','c.id_bagian=b.id_bagian','');
      $this->db->join('iku_proker d','b.id_iku_proker=d.id_iku_proker','');
      $this->db->where('a.status_detail_usulan',3);
      $this->db->where('b.status_usulan',3);
        $this->db->where('b.tahun_proker',$tahun);

      $query = $this->db->get();
      return $query->result();
      }
      function cetak_proker_td()
    {
      $tahun=$this->session->userdata('tahun');
      $tahuntd=$tahun+1;
      $this->db->select('*');
      $this->db->from('detail_usulan_tb a');
      $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
      $this->db->join('sakip_bagian c','c.id_bagian=b.id_bagian','');
      $this->db->join('iku_proker d','b.id_iku_proker=d.id_iku_proker','');
      $this->db->where('a.status_detail_usulan',3);
      $this->db->where('b.status_usulan',3);
        $this->db->where('b.tahun_proker',$tahuntd);

      $query = $this->db->get();
      return $query->result();
      }
       function cetak_usulan_proker_tb()
    {
      $tahun=$this->session->userdata('tahun');
      $this->db->select('*');
      $this->db->from('detail_usulan_tb a');
      $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
      $this->db->join('sakip_bagian c','c.id_bagian=b.id_bagian','');
      $this->db->join('iku_proker d','b.id_iku_proker=d.id_iku_proker','');
        $this->db->where('b.tahun_proker',$tahun);
  $this->db->where('b.status_usulan',1);
      $query = $this->db->get();
      return $query->result();
      }
      function cetak_usulan_proker_td()
    {
      $tahun=$this->session->userdata('tahun');
      $tahuntd=$tahun+1;
      $this->db->select('*');
      $this->db->from('detail_usulan_tb a');
      $this->db->join('usulan_tb b','a.id_usulan_tb=b.id_usulan_tb','');
      $this->db->join('sakip_bagian c','c.id_bagian=b.id_bagian','');
      $this->db->join('iku_proker d','b.id_iku_proker=d.id_iku_proker','');
        $this->db->where('b.tahun_proker',$tahuntd);
          $this->db->where('b.status_usulan',1);

      $query = $this->db->get();
      return $query->result();
      }
		function get_ikk_home()
		{
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_ikk a');
			$this->db->join('sakip_sasaran_kegiatan b','a.id_sasaran_kegiatan=b.id_sasaran_kegiatan','');
			$this->db->where('b.tahun',$tahun);
			$this->db->order_by('a.no_ikk asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_iku()
		{
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_iku a');
			$this->db->join('sakip_bagian b','a.id_bagian=b.id_bagian','left');
			$this->db->join('sakip_ikk c','a.id_ikk=c.id_ikk','');
			$this->db->join('sakip_sasaran_kegiatan d','c.id_sasaran_kegiatan=d.id_sasaran_kegiatan','');
			$this->db->where('d.tahun',$tahun);
			$this->db->order_by('a.no asc');
			$query = $this->db->get();
			return $query->result();
			}
			public function hitung_analisanew($id_iku)
{   
  $this->db->select('*');
		$this->db->from('sakip_analisa');
		$this->db->where('id_iku',$id_iku);
		$this->db->where('status_analisa',1);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
public function hitung_analisapj($id_iku)
{   
  $this->db->select('*');
		$this->db->from('sakip_analisa');
		$this->db->where('id_iku',$id_iku);
		$this->db->where('status_analisa',2);
    $query = $this->db->get();
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
}
			function get_iku_validator()
		{
			$tahun=$this->session->userdata('tahun');
	
			$this->db->distinct();
			$this->db->select('a.id_iku,a.iku,c.bagian,c.id_bagian');
		
			$this->db->from('sakip_iku a');
				$this->db->join('sakip_bagian c','a.id_bagian=c.id_bagian','left');
		//	$this->db->join('sakip_analisa b','a.id_iku=b.id_iku','left');
			$this->db->where('a.tahun_iku',$tahun);
			//	$this->db->where('b.status_analisa',1);
			$this->db->order_by('a.no asc');
			$query = $this->db->get();
			return $query->result();
			
			}
			function get_iku_user()
		{
			$id=$this->session->userdata('id');
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_iku a');
			$this->db->join('sakip_bagian b','a.id_bagian=b.id_bagian','left');
				
			$this->db->join('sakip_ikk c','a.id_ikk=c.id_ikk','');
			$this->db->join('sakip_sasaran_kegiatan d','c.id_sasaran_kegiatan=d.id_sasaran_kegiatan','');
			$this->db->where('d.tahun',$tahun);
			$this->db->where('a.id_bagian',$id);
			$this->db->or_where('a.id_bagian',1);
			$this->db->order_by('a.no asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_analisa($ida)
		{
			$id=$this->session->userdata('id');
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_analisa z');
			$this->db->join('sakip_iku a','a.id_iku=z.id_iku','left');
			$this->db->join('sakip_bagian b','a.id_bagian=b.id_bagian','left');
			$this->db->join('sakip_ikk c','a.id_ikk=c.id_ikk','');
			$this->db->join('sakip_sasaran_kegiatan d','c.id_sasaran_kegiatan=d.id_sasaran_kegiatan','');
			$this->db->join('sakip_triwulan y','z.id_triwulan=y.id_triwulan','');
			$this->db->where('d.tahun',$tahun);
			$this->db->where('z.id_iku',$ida);
			$this->db->order_by('a.menu asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_cetak_analisa()
		{
			$id=$this->session->userdata('id');
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_analisa z');
			$this->db->join('sakip_iku a','a.id_iku=z.id_iku','left');
			$this->db->join('sakip_bagian b','a.id_bagian=b.id_bagian','left');
			$this->db->join('sakip_ikk c','a.id_ikk=c.id_ikk','');
			$this->db->join('sakip_sasaran_kegiatan d','c.id_sasaran_kegiatan=d.id_sasaran_kegiatan','');
			$this->db->join('sakip_triwulan y','z.id_triwulan=y.id_triwulan','');
			$this->db->where('d.tahun',$tahun);
			$this->db->order_by('a.menu asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_analisa_user($ida)
		{
			$id=$this->session->userdata('id');
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_analisa z');
			$this->db->join('sakip_iku a','a.id_iku=z.id_iku','left');
			$this->db->join('sakip_bagian b','a.id_bagian=b.id_bagian','left');
			$this->db->join('sakip_ikk c','a.id_ikk=c.id_ikk','');
			$this->db->join('sakip_sasaran_kegiatan d','c.id_sasaran_kegiatan=d.id_sasaran_kegiatan','');
			$this->db->join('sakip_triwulan y','z.id_triwulan=y.id_triwulan','');
			$this->db->where('d.tahun',$tahun);
			$this->db->where('z.id_iku',$ida);
			$this->db->order_by('a.menu asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_bagian_user()
		{
			$id=$this->session->userdata('id');
			
			$this->db->select('*');
			$this->db->from('sakip_bagian');
			$this->db->where('id_bagian',$id);
			$query = $this->db->get();
			return $query->result();
			}
		  function get_iku1($id_iku)
      {
        $tahun=$this->session->userdata('tahun');
        $this->db->select('*');
        $this->db->from('sakip_iku1 a');
        $this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
        $this->db->where('a.id_iku',$id_iku);
        $this->db->order_by('a.tgl_input desc');
        $query = $this->db->get();
        return $query->result();
        }
				function get_iku10($id_iku)
			{
				$tahun=$this->session->userdata('tahun');
				$this->db->select('*');
				$this->db->from('sakip_iku10 a');
				$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
				$this->db->where('a.id_iku',$id_iku);
        $this->db->order_by('a.tgl_input desc');
				$query = $this->db->get();
				return $query->result();
				}
				function get_bukti($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_bukti_dukung a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->join('sakip_iku c','a.id_iku=c.id_iku','');
					$this->db->where('a.id_iku',$id_iku);
					$query = $this->db->get();
					return $query->result();
					}
				function get_iku3($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku3 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
					function get_iku2($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku2 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
				function get_iku4($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku4 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
					function get_iku7($id_iku)
					{
						$tahun=$this->session->userdata('tahun');
						$this->db->select('*');
						$this->db->from('sakip_iku7 a');
						$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
						$this->db->where('a.id_iku',$id_iku);
            $this->db->order_by('a.tgl_input desc');
						$query = $this->db->get();
						return $query->result();
						}
					function get_iku6($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku6 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
					function get_iku5($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku5 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
					function get_iku9($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku9 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
					function get_iku8($id_iku)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_iku8 a');
					$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
					$this->db->where('a.id_iku',$id_iku);
          $this->db->order_by('a.tgl_input desc');
					$query = $this->db->get();
					return $query->result();
					}
					function get_detail_iku4($id)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('detail_sakip_iku4 a');
					$this->db->join('sakip_iku4 b','b.id_iku4=a.id_iku4','');
					$this->db->where('a.id_iku4',$id);
					$query = $this->db->get();
					return $query->result();
					}
					function get_detail_iku7($id)
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('detail_sakip_iku7 a');
					$this->db->join('sakip_iku7 b','b.id_iku7=a.id_iku7','');
					$this->db->where('a.id_iku7',$id);
					$query = $this->db->get();
					return $query->result();
					}
					function get_triwulan()
				{
					$tahun=$this->session->userdata('tahun');
					$this->db->select('*');
					$this->db->from('sakip_triwulan');
					$this->db->where('status',1);
					$query = $this->db->get();
					return $query->result();
					}
				function get_iku11($id_iku)
			{
				$tahun=$this->session->userdata('tahun');
				$this->db->select('*');
				$this->db->from('sakip_iku11 a');
				$this->db->join('sakip_triwulan z','a.id_triwulan=z.id_triwulan','');
				$this->db->where('a.id_iku',$id_iku);
        $this->db->order_by('a.tgl_input desc');
				$query = $this->db->get();
				return $query->result();
				}
			
		function get_sk()
		{
			$tahun=$this->session->userdata('tahun');
			$this->db->select('*');
			$this->db->from('sakip_sasaran_kegiatan a');
			$this->db->where('a.tahun',$tahun);
			$this->db->order_by('a.sasaran_kegiatan asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_standar_layanan($id_bagian)
			{
				$tahun=$this->session->userdata('tahun');
				$this->db->select('*');
				$this->db->from('sakip_standar_layanan a');
				$this->db->join('sakip_bagian b','a.id_bagian=b.id_bagian','left');
				$this->db->where('b.id_bagian',$id_bagian);
				$query = $this->db->get();
				return $query->result();
				}
				function get_standar_layanan_user()
			{
				$id=$this->session->userdata('id');
				$tahun=$this->session->userdata('tahun');
				$this->db->select('*');
				$this->db->from('sakip_standar_layanan a');
				$this->db->where('a.id_bagian',$id);
				$query = $this->db->get();
				return $query->result();
				}
				function get_standar_layanan_admin()
			{
				$tahun=$this->session->userdata('tahun');
				$this->db->select('*');
				$this->db->from('sakip_standar_layanan');
				$query = $this->db->get();
				return $query->result();
				}
			function get_data($tabel)
	{
		$query = $this->db->get($tabel);
		return $query->result();		
	}
	function m_iku($id_iku = FALSE)
	{
		if($id_iku == FALSE){
			$query = $this->db->get('sakip_iku');
			return $query->result();
		}	

		$query = $this->db->get_where('sakip_iku', array('id_iku' => $id_iku));
        return $query->row();
	}
	function m_iku4($id_iku4 = FALSE)
	{
		if($id_iku4 == FALSE){
			$query = $this->db->get('sakip_iku4');
			return $query->result();
		}	

		$query = $this->db->get_where('sakip_iku4', array('id_iku4' => $id_iku4));
        return $query->row();
	}
	function m_iku7($id_iku7 = FALSE)
	{
		if($id_iku7 == FALSE){
			$query = $this->db->get('sakip_iku7');
			return $query->result();
		}	

		$query = $this->db->get_where('sakip_iku7', array('id_iku7' => $id_iku7));
        return $query->row();
	}
	function m_bagian($id_bagian = FALSE)
	{
		if($id_bagian == FALSE){
			$query = $this->db->get('sakip_bagian');
			return $query->result_array();
		}	

		$query = $this->db->get_where('sakip_bagian', array('id_bagian' => $id_bagian));
        return $query->row_array();
	}
 
}
?>